package com.cg.cgemployeeaddress.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.cgemployeeaddress.beans.Address;

public interface AddressDAO  extends JpaRepository<Address, Integer>{

}
