package com.cg.cgemployeeaddress.services;

import java.util.List;

import com.cg.cgemployeeaddress.beans.Address;
import com.cg.cgemployeeaddress.beans.Employee;
import com.cg.cgemployeeaddress.exceptions.EmployeeNotFoundException;

public interface EmployeeServices {

	Employee acceptEmployeeDetails(Employee employee);
	
	Address acceptEmployeeNewAddress(Address address);

	Employee getEmployeeDetails(int employeeId)throws EmployeeNotFoundException;
	
	Employee getEmployeeNewAddress(int employeeId)throws EmployeeNotFoundException;

	List<Employee>  getAllEmployeeDetails() ;
	
	boolean updateEmployeeAddress(int employeeId)throws EmployeeNotFoundException;
	
	boolean removeEmployeeDetails(int employeeId)throws EmployeeNotFoundException;
	
	
}
