package com.cg.cgemployeeaddress.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.cgemployeeaddress.beans.Employee;

public interface EmployeeDAO extends JpaRepository<Employee, Integer>{

}
