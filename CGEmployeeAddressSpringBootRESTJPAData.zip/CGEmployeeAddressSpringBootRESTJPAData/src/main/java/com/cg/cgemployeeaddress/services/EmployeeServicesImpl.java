package com.cg.cgemployeeaddress.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.cgemployeeaddress.beans.Address;
import com.cg.cgemployeeaddress.beans.Employee;
import com.cg.cgemployeeaddress.daoservices.AddressDAO;
import com.cg.cgemployeeaddress.daoservices.EmployeeDAO;
import com.cg.cgemployeeaddress.exceptions.EmployeeNotFoundException;

@Component("employeeServices")
public class EmployeeServicesImpl implements EmployeeServices{

	@Autowired
	private EmployeeDAO employeeDAO;
	
	@Autowired
	private AddressDAO addressDAO;

	@Override
	public Employee acceptEmployeeDetails(Employee employee) {
		employee=employeeDAO.save(employee);
		return employee;
	}
	
	@Override
	public Address acceptEmployeeNewAddress(Address address) {
		address = addressDAO.save(address);
		return address;
	}

	@Override
	public Employee getEmployeeDetails(int employeeId) throws EmployeeNotFoundException {
		return employeeDAO.findById(employeeId).orElseThrow(()->  new EmployeeNotFoundException("Employee Details Not found for Employee ID. : "+employeeId));
	}
	
	@Override
	public Employee getEmployeeNewAddress(int employeeId) throws EmployeeNotFoundException {
		return addressDAO.findById(employeeId).orElseThrow(()->  new EmployeeNotFoundException("Employee Details Not found for Employee ID. : "+employeeId));
	}

	@Override
	public List<Employee> getAllEmployeeDetails() {
		return employeeDAO.findAll();
	}


	@Override public boolean updateEmployeeAddress(int employeeId) throws EmployeeNotFoundException { 
		Employee employee = getEmployeeDetails(employeeId); 
		Address address = 
		employee.setAddress(new Address(employee.getAddress().setRoad(road),employee.getAddress().setCity(), employee.getAddress().setState(), employee.getAddress().setPincode()));
		employeeDAO.save(employee); 
		return true; 
	}


	@Override
	public boolean removeEmployeeDetails(int employeeId) throws EmployeeNotFoundException {
		employeeDAO.delete(getEmployeeDetails(employeeId));
		return true;
	}

	

}
