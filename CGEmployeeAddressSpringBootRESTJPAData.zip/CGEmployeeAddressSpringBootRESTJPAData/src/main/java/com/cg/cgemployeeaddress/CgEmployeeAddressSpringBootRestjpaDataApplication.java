package com.cg.cgemployeeaddress;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgEmployeeAddressSpringBootRestjpaDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgEmployeeAddressSpringBootRestjpaDataApplication.class, args);
	}

}
