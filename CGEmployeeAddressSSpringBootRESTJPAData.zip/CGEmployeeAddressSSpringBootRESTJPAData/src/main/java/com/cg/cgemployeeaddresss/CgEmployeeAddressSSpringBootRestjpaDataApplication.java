package com.cg.cgemployeeaddresss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgEmployeeAddressSSpringBootRestjpaDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgEmployeeAddressSSpringBootRestjpaDataApplication.class, args);
	}

}
