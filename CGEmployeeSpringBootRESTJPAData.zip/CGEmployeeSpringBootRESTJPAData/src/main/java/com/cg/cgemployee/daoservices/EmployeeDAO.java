package com.cg.cgemployee.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.cgemployee.beans.Employee;

public interface EmployeeDAO extends JpaRepository<Employee, Integer>{

}
