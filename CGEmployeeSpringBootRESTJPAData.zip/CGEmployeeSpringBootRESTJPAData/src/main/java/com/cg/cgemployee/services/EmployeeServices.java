package com.cg.cgemployee.services;

import java.util.List;

import com.cg.cgemployee.beans.Employee;
import com.cg.cgemployee.exceptions.EmployeeNotFoundException;

public interface EmployeeServices {

	Employee acceptEmployeeDetails(Employee employee);

	Employee getEmployeeDetails(int employeeId)throws EmployeeNotFoundException;

	List<Employee>  getAllEmployeeDetails() ;
	
	//boolean updateEmployeeAddress(int employeeId)throws EmployeeNotFoundException;
	
	boolean removeEmployeeDetails(int employeeId)throws EmployeeNotFoundException;
	
	
}
