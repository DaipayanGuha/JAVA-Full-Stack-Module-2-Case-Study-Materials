package com.cg.moviesongs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgMovieSongsSpringBootRestjpaDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgMovieSongsSpringBootRestjpaDataApplication.class, args);
	}

}
